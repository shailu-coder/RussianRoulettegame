package com.example.russianroulettegame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewAnimator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    Button button;
    TextView textView;

    List<String> bullets;

    boolean shuffeld= true;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);


        bullets = new ArrayList<>();
        //add only one bullet in the gun
        bullets.add("No");
        bullets.add("No");
        bullets.add("No");
        bullets.add("No");
        bullets.add("No");
        bullets.add("Yes");


        //Roll the barrel
        Collections.shuffle(bullets);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Roll the barrel
                Collections.shuffle(bullets);
                imageView.setImageResource(R.drawable.ic_gun);
                shuffeld= true;
                textView.setText("Click on the image to shoot");
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (shuffeld) {
                    String currentBullet = bullets.get(0);
                    if (currentBullet.equals("Yes")) {
                        imageView.setImageResource(R.drawable.ic_bang);
                        textView.setText("You are dead!");
                    } else {
                        imageView.setImageResource(R.drawable.ic_click);
                        textView.setText("You are alive! pass the gun to the next player!");
                    }
                    shuffeld=false;
                }else{
                    textView.setText("First roll the barrel!");
                }
            }
        });
    }
}
